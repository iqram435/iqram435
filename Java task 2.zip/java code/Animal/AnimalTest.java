public class AnimalTest {
    public static void main(String[] args) {
      
        Animal a1 = new Animal();
        a1.setSpecies("Dog");
        a1.setAge(5);
        a1.setColor("Brown");

        Animal a2 = new Animal();
        a2.setSpecies("Cat");
        a2.setAge(3);
        a2.setColor("Black");

        Animal a3 = new Animal();
        a3.setSpecies("Bird");
        a3.setAge(2);
        a3.setColor("Yellow");

        Animal a4 = new Animal();
        a4.setSpecies("Fish");
        a4.setAge(1);
        a4.setColor("Blue");

        Animal a5 = new Animal();
        a5.setSpecies("Horse");
        a5.setAge(7);
        a5.setColor("White");

        System.out.println("--- Animal Details ---");
        a1.display();
        System.out.println();
        a2.display();
        System.out.println();
        a3.display();
        System.out.println();
        a4.display();
        System.out.println();
        a5.display();
    }
}
