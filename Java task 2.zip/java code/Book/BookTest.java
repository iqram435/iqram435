public class BookTest {
    public static void main(String[] args) {
        Book b1 = new Book();
        b1.setTitle("1984");
        b1.setAuthor("George Orwell");
        b1.setPages(328);

        Book b2 = new Book();
        b2.setTitle("To Kill a Mockingbird");
        b2.setAuthor("Harper Lee");
        b2.setPages(281);

        Book b3 = new Book();
        b3.setTitle("The Hobbit");
        b3.setAuthor("J.R.R. Tolkien");
        b3.setPages(310);

        System.out.println("--- Book Details ---");
        b1.display();
        System.out.println();
        b2.display();
        System.out.println();
        b3.display();
    }
}
