public class CarTest {
    public static void main(String[] args) {
        
        Car c1 = new Car();
        c1.setBrand("Toyota");
        c1.setModel("Corolla");
        c1.setYear(2020);

        Car c2 = new Car();
        c2.setBrand("Honda");
        c2.setModel("Civic");
        c2.setYear(2019);

        Car c3 = new Car();
        c3.setBrand("Ford");
        c3.setModel("Mustang");
        c3.setYear(2021);

        
        System.out.println("--- Car Details ---");
        c1.display();
        System.out.println();
        c2.display();
        System.out.println();
        c3.display();
    }
}
