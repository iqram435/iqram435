public class StudentMain {
    public static void main(String[] args) {
   
        Student s1 = new Student();
        s1.setName("Alice");
        s1.setAge(20);
        s1.setDepartment("Computer Science");

        Student s2 = new Student();
        s2.setName("Bob");
        s2.setAge(22);
        s2.setDepartment("Electrical Engineering");

        Student s3 = new Student();
        s3.setName("Charlie");
        s3.setAge(21);
        s3.setDepartment("Mechanical Engineering");

        Student s4 = new Student();
        s4.setName("David");
        s4.setAge(23);
        s4.setDepartment("Civil Engineering");

        Student s5 = new Student();
        s5.setName("Eve");
        s5.setAge(19);
        s5.setDepartment("Architecture");

      
        System.out.println("--- Student Details ---");
        s1.display();
        System.out.println();
        s2.display();
        System.out.println();
        s3.display();
        System.out.println();
        s4.display();
        System.out.println();
        s5.display();
    }
}
