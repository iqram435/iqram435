public class MovieTest {
    public static void main(String[] args) {
      
        Movie m1 = new Movie();
        m1.setTitle("Inception");
        m1.setYear(2010);
        m1.setGenre("Sci-Fi");

        Movie m2 = new Movie();
        m2.setTitle("The Godfather");
        m2.setYear(1972);
        m2.setGenre("Crime");

        Movie m3 = new Movie();
        m3.setTitle("Titanic");
        m3.setYear(1997);
        m3.setGenre("Romance");

       
        System.out.println("--- Movie Details ---");
        m1.display();
        System.out.println();
        m2.display();
        System.out.println();
        m3.display();
    }
}
